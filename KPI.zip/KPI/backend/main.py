from fastapi import FastAPI, Depends, HTTPException, Form, File, UploadFile, Header
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from pydantic import BaseModel, EmailStr, constr
from typing import Optional, List
import os
from dotenv import load_dotenv
from database import FormData, get_db, init_db
from datetime import datetime, timedelta
import jwt
import logging

# Configure logging
logging.basicConfig(filename='api.log', level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

load_dotenv()
app = FastAPI()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="api/login")

JWT_SECRET = os.getenv("JWT_SECRET")
JWT_ALGORITHM = os.getenv("JWT_ALGORITHM")

# Hardcoded user for simplicity (replace with DB in production)
HARDCODED_USER = {"phone": "7760873976", "password": "to_share@123"}

class FormDataCreate(BaseModel):
    name: constr(min_length=1, max_length=100)
    phone: constr(pattern=r'^\d{10}$')
    email: EmailStr
    address: constr(min_length=1, max_length=500)

class FormDataResponse(BaseModel):
    id: int
    name: str
    phone: str
    email: str
    address: str
    file_name: Optional[str]
    created_at: str

    class Config:
        orm_mode = True

class LoginRequest(BaseModel):
    phone: str
    password: str

def create_jwt_token(data: dict):
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(hours=24)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, JWT_SECRET, algorithm=JWT_ALGORITHM)
    return encoded_jwt

async def get_current_user(token: str = Depends(oauth2_scheme)):
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        phone: str = payload.get("sub")
        if phone != HARDCODED_USER["phone"]:
            raise HTTPException(status_code=401, detail="Invalid credentials")
        return phone
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Invalid token")
    except Exception as e:
        logger.error(f"Authentication error: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.on_event("startup")
def on_startup():
    init_db()

@app.post("/api/login")
async def login(request: LoginRequest):
    logger.info(f"Login attempt for phone: {request.phone}")
    if (request.phone == HARDCODED_USER["phone"] and 
        request.password == HARDCODED_USER["password"]):
        token = create_jwt_token({"sub": request.phone})
        return {"access_token": token, "token_type": "bearer"}
    logger.warning(f"Failed login for phone: {request.phone}")
    raise HTTPException(status_code=401, detail="Invalid phone or password")

@app.post("/api/submitForm", response_model=FormDataResponse)
async def submit_form(
    name: str = Form(...),
    phone: str = Form(...),
    email: str = Form(...),
    address: str = Form(...),
    file: UploadFile = File(None),
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    try:
        logger.info(f"Submitting form for user: {current_user}")
        # Input validation
        form_data = FormDataCreate(name=name, phone=phone, email=email, address=address)
        
        # File validation
        file_content = None
        file_name = None
        if file:
            if file.content_type not in ['image/jpeg', 'image/png', 'application/pdf']:
                logger.warning(f"Invalid file type: {file.content_type}")
                raise HTTPException(status_code=400, detail="Invalid file type. Only JPEG, PNG, or PDF allowed")
            file_size = len(await file.read())
            if file_size > 5 * 1024 * 1024:  # 5MB limit
                logger.warning(f"File too large: {file_size} bytes")
                raise HTTPException(status_code=400, detail="File size exceeds 5MB limit")
            await file.seek(0)  # Reset file pointer
            file_content = await file.read()
            file_name = file.filename

        # Create database entry
        db_form = FormData(
            name=form_data.name,
            phone=form_data.phone,
            email=form_data.email,
            address=form_data.address,
            file_content=file_content,
            file_name=file_name
        )
        
        db.add(db_form)
        db.commit()
        db.refresh(db_form)
        
        logger.info(f"Form submitted successfully: ID {db_form.id}")
        return db_form
    except Exception as e:
        logger.error(f"Error submitting form: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/getFormData", response_model=List[FormDataResponse])
async def get_form_data(
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user),
    page: int = 1,
    page_size: int = 10
):
    try:
        logger.info(f"Fetching form data for user: {current_user}, page: {page}, page_size: {page_size}")
        offset = (page - 1) * page_size
        forms = db.query(FormData).order_by(FormData.created_at.desc()).offset(offset).limit(page_size).all()
        return forms
    except Exception as e:
        logger.error(f"Error fetching form data: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)