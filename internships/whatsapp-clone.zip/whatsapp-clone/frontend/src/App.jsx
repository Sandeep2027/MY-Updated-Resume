import React, { useState, useEffect } from 'react';
import io from 'socket.io-client';
import ChatList from './components/ChatList';
import ChatWindow from './components/ChatWindow';
import SearchBar from './components/SearchBar';
import './App.css';
import './tailwind.css';

const socket = io('http://localhost:8000');

function App() {
  const [selectedChat, setSelectedChat] = useState(null);
  const [messages, setMessages] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    socket.on('connect', () => {
      console.log('Connected to WebSocket');
    });

    socket.on('message', (message) => {
      if (message.data.wa_id === selectedChat) {
        setMessages((prev) => [...prev, message.data]);
      }
    });

    socket.on('typing', (data) => {
      if (data.wa_id === selectedChat) {
        setMessages((prev) => ({ ...prev, isTyping: data.isTyping }));
      }
    });

    return () => {
      socket.off('message');
      socket.off('typing');
    };
  }, [selectedChat]);

  return (
    <div className="flex h-screen bg-gray-100 font-sans">
      <div className="flex flex-col w-full md:w-1/3 bg-white border-r border-gray-200">
        <SearchBar searchQuery={searchQuery} setSearchQuery={setSearchQuery} />
        <ChatList onSelectChat={setSelectedChat} searchQuery={searchQuery} />
      </div>
      <ChatWindow selectedChat={selectedChat} messages={messages} setMessages={setMessages} socket={socket} />
    </div>
  );
}

export default App;
