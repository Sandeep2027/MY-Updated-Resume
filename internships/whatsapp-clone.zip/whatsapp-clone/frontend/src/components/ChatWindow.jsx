import React, { useEffect, useState, useRef } from 'react';
import axios from 'axios';
import MessageBubble from './MessageBubble';
import TypingIndicator from './TypingIndicator';

function ChatWindow({ selectedChat, messages, setMessages, socket }) {
  const [message, setMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    if (selectedChat) {
      socket.emit('join', selectedChat);
      axios.get(`http://localhost:8000/messages/${selectedChat}`).then((response) => {
        setMessages(response.data);
      });
    }
  }, [selectedChat, setMessages]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = async () => {
    if (message.trim() === '') return;
    const newMessage = {
      wa_id: selectedChat,
      content: message,
      sender: 'user',
    };
    await axios.post('http://localhost:8000/messages/', newMessage);
    setMessage('');
    socket.emit('message', { type: 'typing', wa_id: selectedChat, isTyping: false });
  };

  const handleTyping = (e) => {
    setMessage(e.target.value);
    const typing = e.target.value.length > 0;
    if (typing !== isTyping) {
      setIsTyping(typing);
      socket.emit('message', { type: 'typing', wa_id: selectedChat, isTyping: typing });
    }
  };

  const addReaction = async (messageId, emoji) => {
    await axios.post(`http://localhost:8000/messages/${messageId}/react`, { reaction: emoji, user_id: 'user' });
  };

  return (
    <div className="flex flex-col w-full md:w-2/3 bg-[url('https://web.whatsapp.com/img/bg-chat-tile_9e8a2898faedb7e.webp')]">
      {selectedChat ? (
        <>
          <div className="p-4 bg-gray-50 border-b border-gray-200 flex items-center">
            <img
              src="https://via.placeholder.com/40"
              alt="Profile"
              className="w-10 h-10 rounded-full mr-3"
            />
            <div>
              <h3 className="font-semibold">{selectedChat}</h3>
              <p className="text-sm text-gray-500">Online</p>
            </div>
          </div>
          <div className="flex-1 overflow-y-auto p-4">
            {messages.map((msg) => (
              <MessageBubble key={msg.id} message={msg} onReact={addReaction} />
            ))}
            <TypingIndicator isTyping={isTyping} />
            <div ref={messagesEndRef} />
          </div>
          <div className="p-4 bg-gray-50 border-t border-gray-200">
            <input
              type="text"
              value={message}
              onChange={handleTyping}
              onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
              placeholder="Type a message..."
              className="w-full p-3 rounded-full border-none outline-none bg-white"
            />
          </div>
        </>
      ) : (
        <div className="flex-1 flex items-center justify-center text-gray-500">
          Select a chat to start messaging
        </div>
      )}
    </div>
  );
}

export default ChatWindow;
