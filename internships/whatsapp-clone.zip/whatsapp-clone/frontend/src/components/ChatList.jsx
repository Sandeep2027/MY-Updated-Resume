import React, { useState, useEffect } from 'react';
import axios from 'axios';

function ChatList({ onSelectChat, searchQuery }) {
  const [chats, setChats] = useState([]);

  useEffect(() => {
    const fetchChats = async () => {
      const response = await axios.get('http://localhost:8000/messages/chats', {
        params: { search: searchQuery }
      });
      setChats(response.data);
    };
    fetchChats();
  }, [searchQuery]);

  return (
    <div className="flex-1 overflow-y-auto">
      {chats.map((chat) => (
        <div
          key={chat.wa_id}
          className="p-4 border-b border-gray-200 hover:bg-gray-100 cursor-pointer"
          onClick={() => onSelectChat(chat.wa_id)}
        >
          <div className="flex items-center">
            <img
              src={chat.profile_pic || 'https://via.placeholder.com/40'}
              alt="Profile"
              className="w-10 h-10 rounded-full mr-3"
            />
            <div>
              <h3 className="font-semibold">{chat.name || chat.wa_id}</h3>
              <p className="text-sm text-gray-500">
                {chat.last_seen ? `Last seen: ${new Date(chat.last_seen).toLocaleString()}` : 'No last seen'}
              </p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

export default ChatList;
