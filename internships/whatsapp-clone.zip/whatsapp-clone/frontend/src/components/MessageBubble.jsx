import React from 'react';

function MessageBubble({ message, onReact }) {
  const reactions = Object.entries(message.reactions || {});
  return (
    <div className={`chat-bubble ${message.sender === 'user' ? 'sent' : 'received'}`}>
      {message.media_url && (
        message.media_type === 'image' ? (
          <img src={message.media_url} alt="Media" className="max-w-full rounded-lg mb-2" />
        ) : (
          <video src={message.media_url} controls className="max-w-full rounded-lg mb-2" />
        )
      )}
      <p>{message.content}</p>
      <div className="status-indicator">
        {new Date(message.timestamp).toLocaleString()} - {message.status}
        {message.is_forwarded && <span className="ml-2 text-xs">Forwarded</span>}
      </div>
      {reactions.length > 0 && (
        <div className="flex space-x-1 mt-1">
          {reactions.map(([user, emoji]) => (
            <span key={user} className="text-sm">{emoji}</span>
          ))}
        </div>
      )}
      <div className="flex space-x-2 mt-1">
        <button onClick={() => onReact(message.id, '👍')} className="text-sm">👍</button>
        <button onClick={() => onReact(message.id, '❤️')} className="text-sm">❤️</button>
        <button onClick={() => onReact(message.id, '😂')} className="text-sm">😂</button>
      </div>
    </div>
  );
}

export default MessageBubble;
