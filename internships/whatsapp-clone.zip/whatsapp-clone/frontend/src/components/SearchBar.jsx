import React from 'react';

function SearchBar({ searchQuery, setSearchQuery }) {
  return (
    <div className="p-4 border-b border-gray-200">
      <input
        type="text"
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
        placeholder="Search chats..."
        className="w-full p-3 rounded-full border-none outline-none bg-gray-100"
      />
    </div>
  );
}

export default SearchBar;
