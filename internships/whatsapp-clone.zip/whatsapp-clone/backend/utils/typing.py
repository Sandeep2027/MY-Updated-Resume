from datetime import datetime
from database import get_collection

async def update_typing_status(wa_id: str, is_typing: bool):
    collection = get_collection("users")
    await collection.update_one(
        {"wa_id": wa_id},
        {"$set": {"is_typing": is_typing, "last_typed": datetime.utcnow()}},
        upsert=True
    )
