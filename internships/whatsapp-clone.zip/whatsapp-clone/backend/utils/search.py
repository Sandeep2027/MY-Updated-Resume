from database import get_collection

async def search_messages(wa_id: str, query: str):
    collection = get_collection("processed_messages")
    messages = await collection.find({
        "wa_id": wa_id,
        "$text": {"$search": query}
    }).sort("timestamp", 1).to_list(1000)
    for msg in messages:
        msg["id"] = str(msg["_id"])
        del msg["_id"]
    return messages
