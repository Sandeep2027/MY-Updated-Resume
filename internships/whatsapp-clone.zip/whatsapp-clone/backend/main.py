from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from routers import messages, webhook, users
from database import connect_to_mongo, close_mongo_connection
import asyncio
import json

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(messages.router)
app.include_router(webhook.router)
app.include_router(users.router)

connected_clients = {}
typing_status = {}

@app.websocket("/ws/{wa_id}")
async def websocket_endpoint(websocket: WebSocket, wa_id: str):
    await websocket.accept()
    if wa_id not in connected_clients:
        connected_clients[wa_id] = set()
    connected_clients[wa_id].add(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            message = json.loads(data)
            if message.get("type") == "typing":
                typing_status[wa_id] = message.get("isTyping")
                await broadcast_typing(wa_id, message.get("isTyping"))
    except WebSocketDisconnect:
        connected_clients[wa_id].remove(websocket)
        if not connected_clients[wa_id]:
            del connected_clients[wa_id]
            if wa_id in typing_status:
                del typing_status[wa_id]
                await broadcast_typing(wa_id, False)

async def broadcast_message(wa_id, message):
    if wa_id in connected_clients:
        for client in connected_clients[wa_id]:
            await client.send_json({"type": "message", "data": message})

async def broadcast_typing(wa_id, is_typing):
    if wa_id in connected_clients:
        for client in connected_clients[wa_id]:
            await client.send_json({"type": "typing", "data": {"wa_id": wa_id, "isTyping": is_typing}})

@app.on_event("startup")
async def startup_event():
    await connect_to_mongo()

@app.on_event("shutdown")
async def shutdown_event():
    await close_mongo_connection()
