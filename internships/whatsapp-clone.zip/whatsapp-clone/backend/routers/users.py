from fastapi import APIRouter
from models import User
from database import get_collection
from datetime import datetime

router = APIRouter(prefix="/users", tags=["users"])

@router.get("/{wa_id}")
async def get_user(wa_id: str):
    collection = get_collection("users")
    user = await collection.find_one({"wa_id": wa_id})
    if user:
        user["id"] = str(user["_id"])
        del user["_id"]
        return user
    return {"wa_id": wa_id, "name": f"User {wa_id}", "profile_pic": null, "last_seen": null}

@router.post("/{wa_id}/last-seen")
async def update_last_seen(wa_id: str):
    collection = get_collection("users")
    await collection.update_one(
        {"wa_id": wa_id},
        {"$set": {"last_seen": datetime.utcnow()}},
        upsert=True
    )
    return {"status": "updated"}
