from fastapi import APIRouter, HTTPException
from models import Message, MessageCreate
from database import get_collection
from bson import ObjectId
from datetime import datetime
from main import broadcast_message
from utils.search import search_messages

router = APIRouter(prefix="/messages", tags=["messages"])

@router.get("/{wa_id}")
async def get_messages(wa_id: str):
    collection = get_collection("processed_messages")
    messages = await collection.find({"wa_id": wa_id}).sort("timestamp", 1).to_list(1000)
    for msg in messages:
        msg["id"] = str(msg["_id"])
        del msg["_id"]
    return messages

@router.get("/search/{wa_id}")
async def search_messages_endpoint(wa_id: str, query: str):
    messages = await search_messages(wa_id, query)
    return messages

@router.post("/")
async def create_message(message: MessageCreate):
    collection = get_collection("processed_messages")
    msg_dict = message.dict()
    msg_dict["timestamp"] = datetime.utcnow()
    msg_dict["status"] = "sent"
    result = await collection.insert_one(msg_dict)
    new_message = await collection.find_one({"_id": result.inserted_id})
    new_message["id"] = str(new_message["_id"])
    del new_message["_id"]
    await broadcast_message(new_message["wa_id"], new_message)
    return new_message

@router.post("/{message_id}/react")
async def add_reaction(message_id: str, reaction: str, user_id: str):
    collection = get_collection("processed_messages")
    result = await collection.update_one(
        {"_id": ObjectId(message_id)},
        {"$set": {f"reactions.{user_id}": reaction}}
    )
    if result.modified_count:
        updated_message = await collection.find_one({"_id": ObjectId(message_id)})
        updated_message["id"] = str(updated_message["_id"])
        del updated_message["_id"]
        await broadcast_message(updated_message["wa_id"], updated_message)
        return updated_message
    raise HTTPException(status_code=404, detail="Message not found")
