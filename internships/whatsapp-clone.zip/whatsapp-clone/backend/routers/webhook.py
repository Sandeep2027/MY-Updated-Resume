from fastapi import APIRouter, HTTPException
from database import get_collection
from bson import ObjectId
from datetime import datetime
from main import broadcast_message

router = APIRouter(prefix="/webhook", tags=["webhook"])

@router.post("/")
async def process_webhook(payload: dict):
    collection = get_collection("processed_messages")
    
    if payload.get("type") == "message":
        message = {
            "wa_id": payload.get("wa_id"),
            "sender": payload.get("sender", "contact"),
            "content": payload.get("content"),
            "timestamp": datetime.fromisoformat(payload.get("timestamp")),
            "status": "received",
            "meta_msg_id": payload.get("meta_msg_id"),
            "reactions": {},
            "is_forwarded": payload.get("is_forwarded", False),
            "media_url": payload.get("media_url"),
            "media_type": payload.get("media_type")
        }
        result = await collection.insert_one(message)
        message["id"] = str(result.inserted_id)
        await broadcast_message(message["wa_id"], message)
        return {"status": "processed"}

    elif payload.get("type") == "status":
        meta_msg_id = payload.get("meta_msg_id")
        status = payload.get("status")
        result = await collection.update_one(
            {"meta_msg_id": meta_msg_id},
            {"$set": {"status": status, "timestamp": datetime.fromisoformat(payload.get("timestamp"))}}
        )
        if result.modified_count:
            updated_message = await collection.find_one({"meta_msg_id": meta_msg_id})
            updated_message["id"] = str(updated_message["_id"])
            del updated_message["_id"]
            await broadcast_message(updated_message["wa_id"], updated_message)
        return {"status": "updated"}

    raise HTTPException(status_code=400, detail="Invalid payload type")
