from pydantic import BaseModel
from typing import Optional, List, Dict
from datetime import datetime

class Message(BaseModel):
    id: Optional[str] = None
    wa_id: str
    sender: str
    content: str
    timestamp: datetime
    status: str
    meta_msg_id: Optional[str] = None
    reactions: Optional[Dict[str, str]] = {}
    is_forwarded: Optional[bool] = False
    media_url: Optional[str] = None
    media_type: Optional[str] = None

class MessageCreate(BaseModel):
    wa_id: str
    content: str
    sender: str = "user"
    media_url: Optional[str] = None
    media_type: Optional[str] = None

class User(BaseModel):
    wa_id: str
    name: Optional[str] = None
    profile_pic: Optional[str] = None
    last_seen: Optional[datetime] = None
