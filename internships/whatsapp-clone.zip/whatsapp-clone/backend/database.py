from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import MongoClient
from bson import ObjectId
import os
from dotenv import load_dotenv

load_dotenv()

MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
client = AsyncIOMotorClient(MONGO_URI)
db = client["whatsapp"]

async def connect_to_mongo():
    await client.start_session()

async def close_mongo_connection():
    client.close()

def get_collection(collection_name):
    return db[collection_name]
