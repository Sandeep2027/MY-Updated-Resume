import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import './index.css';
import Forms from './pages/Forms';
import Editor from './pages/Editor';
import Fill from './pages/Fill';

function App(){
  return (
    <BrowserRouter>
      <div className="p-4 max-w-4xl mx-auto">
        <header className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold">Custom Form Builder</h1>
          <nav>
            <Link to="/" className="mr-4">Forms</Link>
            <Link to="/editor">New Form</Link>
          </nav>
        </header>
        <Routes>
          <Route path="/" element={<Forms/>} />
          <Route path="/editor/:id" element={<Editor/>} />
          <Route path="/editor" element={<Editor/>} />
          <Route path="/fill/:id" element={<Fill/>} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

createRoot(document.getElementById('root')).render(<App />);
