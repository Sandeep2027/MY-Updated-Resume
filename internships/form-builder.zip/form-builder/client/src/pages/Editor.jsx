import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams, useNavigate } from "react-router-dom";

const emptyConfig = { questions: [] };

function QuestionEditor({ q, onChange, onRemove }) {
  return (
    <div className="p-5 bg-white rounded-2xl shadow-md border border-gray-200">
      <div className="flex justify-between items-center">
        <span className="text-lg font-semibold capitalize">{q.type} Question</span>
        <button
          onClick={() => onRemove(q.id)}
          className="text-red-600 hover:text-red-800 transition"
        >
          ✕ Remove
        </button>
      </div>

      {/* Question Label */}
      <label className="block mt-4 font-medium">Label</label>
      <input
        value={q.label}
        onChange={(e) => onChange({ ...q, label: e.target.value })}
        className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
      />

      {/* Categorize */}
      {q.type === "categorize" && (
        <>
          <label className="block mt-4 font-medium">Items (comma separated)</label>
          <input
            value={(q.data.items || []).join(",")}
            onChange={(e) =>
              onChange({
                ...q,
                data: { ...q.data, items: e.target.value.split(",").map((s) => s.trim()) },
              })
            }
            className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <label className="block mt-4 font-medium">Categories (comma separated)</label>
          <input
            value={(q.data.categories || []).join(",")}
            onChange={(e) =>
              onChange({
                ...q,
                data: { ...q.data, categories: e.target.value.split(",").map((s) => s.trim()) },
              })
            }
            className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </>
      )}

      {/* Cloze */}
      {q.type === "cloze" && (
        <>
          <label className="block mt-4 font-medium">Cloze Hint / Template</label>
          <input
            value={q.data.template || ""}
            onChange={(e) =>
              onChange({ ...q, data: { ...q.data, template: e.target.value } })
            }
            className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </>
      )}

      {/* Comprehension */}
      {q.type === "comprehension" && (
        <>
          <label className="block mt-4 font-medium">Passage</label>
          <textarea
            value={q.data.passage || ""}
            onChange={(e) =>
              onChange({ ...q, data: { ...q.data, passage: e.target.value } })
            }
            className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </>
      )}
    </div>
  );
}

export default function Editor() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [form, setForm] = useState({ title: "", description: "", config: emptyConfig });

  useEffect(() => {
    if (id) {
      axios.get(`http://localhost:4000/api/forms/${id}`).then((r) => setForm(r.data));
    }
  }, [id]);

  function addQuestion(type) {
    const q = {
      id: "q_" + Date.now(),
      type,
      label: type + " question",
      data: {},
    };
    setForm((f) => ({
      ...f,
      config: { ...f.config, questions: [...(f.config.questions || []), q] },
    }));
  }

  function updateQuestion(q) {
    setForm((f) => ({
      ...f,
      config: {
        ...f.config,
        questions: f.config.questions.map((x) => (x.id === q.id ? q : x)),
      },
    }));
  }

  function removeQuestion(qid) {
    setForm((f) => ({
      ...f,
      config: {
        ...f.config,
        questions: f.config.questions.filter((x) => x.id !== qid),
      },
    }));
  }

  async function save(e) {
    e.preventDefault();
    const payload = new FormData();
    payload.append("title", form.title || "");
    payload.append("description", form.description || "");
    payload.append("config", JSON.stringify(form.config || {}));

    try {
      if (id) {
        await axios.put(`http://localhost:4000/api/forms/${id}`, payload);
        alert("Saved");
      } else {
        const r = await axios.post("http://localhost:4000/api/forms", payload);
        navigate(`/editor/${r.data.id}`);
      }
    } catch (err) {
      console.error(err);
      alert("Save failed");
    }
  }

  return (
    <div>
      <h2 className="text-3xl font-bold mb-6">Form Editor</h2>
      <form onSubmit={save} className="space-y-6">
        {/* Title */}
        <div>
          <label className="block text-lg font-medium">Title</label>
          <input
            value={form.title || ""}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        {/* Description */}
        <div>
          <label className="block text-lg font-medium">Description</label>
          <input
            value={form.description || ""}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        {/* Question Type Buttons */}
        <div className="flex gap-3">
          {["categorize", "cloze", "comprehension"].map((type) => (
            <button
              key={type}
              type="button"
              onClick={() => addQuestion(type)}
              className="px-5 py-2 bg-blue-600 text-white rounded-lg shadow hover:bg-blue-700 transition"
            >
              Add {type.charAt(0).toUpperCase() + type.slice(1)}
            </button>
          ))}
        </div>

        {/* Question List */}
        <div className="space-y-4">
          {(form.config.questions || []).map((q) => (
            <QuestionEditor
              key={q.id}
              q={q}
              onChange={updateQuestion}
              onRemove={removeQuestion}
            />
          ))}
        </div>

        {/* Save */}
        <div>
          <button className="px-6 py-3 bg-green-600 text-white font-semibold rounded-lg shadow hover:bg-green-700 transition">
            Save Form
          </button>
          {id && (
            <a
              className="ml-4 text-blue-600 hover:underline"
              href={`/fill/${id}`}
            >
              Open Fill Link
            </a>
          )}
        </div>
      </form>
    </div>
  );
}
