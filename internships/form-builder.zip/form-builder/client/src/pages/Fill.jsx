import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";

export default function Fill() {
  const { id } = useParams();
  const [form, setForm] = useState(null);
  const [answers, setAnswers] = useState({});

  useEffect(() => {
    axios.get(`http://localhost:4000/api/forms/${id}`).then((r) => setForm(r.data));
  }, [id]);

  if (!form) return <div>Loading...</div>;
  const qs = form.config.questions || [];

  function submit(e) {
    e.preventDefault();
    axios
      .post(`http://localhost:4000/api/forms/${id}/responses`, { answers })
      .then(() => alert("Submitted"))
      .catch(() => alert("Submit failed"));
  }

  return (
    <div>
      <h2 className="text-3xl font-bold mb-2">{form.title}</h2>
      <p className="text-gray-600 mb-6">{form.description}</p>

      <form onSubmit={submit} className="space-y-6">
        {qs.map((q) => {
          if (q.type === "categorize") {
            return (
              <div
                key={q.id}
                className="p-5 bg-white border rounded-2xl shadow-md space-y-3"
              >
                <div className="font-semibold text-lg">{q.label}</div>
                {(q.data.items || []).map((it, idx) => (
                  <div key={idx} className="flex items-center gap-3">
                    <div className="w-32">{it}</div>
                    <select
                      onChange={(e) =>
                        setAnswers((a) => ({
                          ...a,
                          [q.id]: { ...a[q.id], [it]: e.target.value },
                        }))
                      }
                      className="p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="">Select</option>
                      {(q.data.categories || []).map((c) => (
                        <option key={c} value={c}>
                          {c}
                        </option>
                      ))}
                    </select>
                  </div>
                ))}
              </div>
            );
          }

          if (q.type === "cloze") {
            return (
              <div
                key={q.id}
                className="p-5 bg-white border rounded-2xl shadow-md space-y-2"
              >
                <div className="font-semibold text-lg">{q.label}</div>
                <input
                  onChange={(e) =>
                    setAnswers((a) => ({ ...a, [q.id]: e.target.value }))
                  }
                  className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            );
          }

          if (q.type === "comprehension") {
            return (
              <div
                key={q.id}
                className="p-5 bg-white border rounded-2xl shadow-md space-y-3"
              >
                <div className="font-semibold text-lg">{q.label}</div>
                <p className="text-gray-700 text-sm">{q.data.passage}</p>
                <textarea
                  onChange={(e) =>
                    setAnswers((a) => ({ ...a, [q.id]: e.target.value }))
                  }
                  className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            );
          }

          return null;
        })}

        <button className="px-6 py-3 bg-green-600 text-white font-semibold rounded-lg shadow hover:bg-green-700 transition">
          Submit
        </button>
      </form>
    </div>
  );
}
