import React, {useEffect, useState} from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

export default function Forms(){
  const [forms, setForms] = useState([]);
  useEffect(()=>{ axios.get('http://localhost:4000/api/forms').then(r=>setForms(r.data)).catch(()=>{}); },[]);
  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">Forms</h2>
      <div className="space-y-4">
        {forms.map(f=>(
          <div key={f.id} className="p-4 border rounded-md flex items-center justify-between">
            <div>
              <div className="font-medium">{f.title}</div>
              <div className="text-sm text-gray-600">{f.description}</div>
            </div>
            <div className="space-x-2">
              <Link to={`/editor/${f.id}`} className="text-sm">Edit</Link>
              <a href={`/fill/${f.id}`} className="text-sm">Fill</a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
