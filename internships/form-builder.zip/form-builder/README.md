# Custom Form Builder (Node + sqlite3 + React + Tailwind)

This project is a minimal implementation of the requested form builder using:
- Backend: Node.js + Express + sqlite3
- Frontend: React (Vite) + Tailwind CSS
- Image uploads handled by multer (uploaded to server/uploads)

## Structure

- server/: Express backend (runs on port 4000)
- client/: Vite React frontend (runs on port 5173)

## Setup (run locally)

1. Server
```bash
cd server
npm install
node seed.js  # optional to add a sample form
npm start
```

2. Client
```bash
cd client
npm install
npm run dev
```

Open the frontend at http://localhost:5173 and the server API at http://localhost:4000.

## Notes

- The database file is `server/data.sqlite3`.
- This is a minimal, functional starting point. You can improve styling, add image upload from the editor, drag-and-drop categorization UI, authentication, and deployment scripts.

