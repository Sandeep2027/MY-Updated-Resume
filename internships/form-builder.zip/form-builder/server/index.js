const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const db = require('./db');

const app = express();
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// simple file upload using multer
const upload = multer({ dest: path.join(__dirname, 'uploads/') });

// --- Routes ---
// create a form
app.post('/api/forms', upload.single('headerImage'), async (req, res) => {
  try {
    const { title, description, config } = req.body;
    const headerImage = req.file ? '/uploads/' + path.basename(req.file.path) : null;
    const stmt = db.prepare("INSERT INTO forms (title, description, header_image, config) VALUES (?,?,?,?)");
    stmt.run(title, description, headerImage, config || '{}', function(err) {
      if (err) return res.status(500).json({error: err.message});
      res.json({id: this.lastID});
    });
  } catch(e) {
    res.status(500).json({error: e.message});
  }
});

// update form
app.put('/api/forms/:id', upload.single('headerImage'), (req, res) => {
  try {
    const id = req.params.id;
    const { title, description, config } = req.body;
    const headerImage = req.file ? '/uploads/' + path.basename(req.file.path) : null;
    const sql = headerImage ?
      "UPDATE forms SET title=?, description=?, header_image=?, config=? WHERE id=?" :
      "UPDATE forms SET title=?, description=?, config=? WHERE id=?";
    const params = headerImage ? [title, description, headerImage, config||'{}', id] : [title, description, config||'{}', id];
    db.run(sql, params, function(err) {
      if (err) return res.status(500).json({error: err.message});
      res.json({updated: this.changes});
    });
  } catch(e) {
    res.status(500).json({error: e.message});
  }
});

// get form
app.get('/api/forms/:id', (req, res) => {
  db.get("SELECT * FROM forms WHERE id = ?", [req.params.id], (err,row) => {
    if (err) return res.status(500).json({error: err.message});
    if (!row) return res.status(404).json({error:'not found'});
    // parse config JSON
    try { row.config = JSON.parse(row.config); } catch(e){ row.config = {}; }
    res.json(row);
  });
});

// submit responses for a form
app.post('/api/forms/:id/responses', (req, res) => {
  try {
    const formId = req.params.id;
    const { answers } = req.body;
    const stmt = db.prepare("INSERT INTO responses (form_id, answers, created_at) VALUES (?,?,datetime('now'))");
    stmt.run(formId, JSON.stringify(answers||{}), function(err) {
      if (err) return res.status(500).json({error: err.message});
      res.json({id: this.lastID});
    });
  } catch(e) {
    res.status(500).json({error: e.message});
  }
});

// list responses
app.get('/api/forms/:id/responses', (req, res) => {
  db.all("SELECT id, answers, created_at FROM responses WHERE form_id = ? ORDER BY created_at DESC", [req.params.id], (err, rows) => {
    if (err) return res.status(500).json({error: err.message});
    rows = rows.map(r => ({id: r.id, created_at: r.created_at, answers: JSON.parse(r.answers)}));
    res.json(rows);
  });
});

// list forms
app.get('/api/forms', (req, res) => {
  db.all("SELECT id, title, description, header_image FROM forms ORDER BY id DESC", [], (err, rows) => {
    if (err) return res.status(500).json({error: err.message});
    res.json(rows);
  });
});

// serve frontend in production (optional)
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log('Server running on', PORT));
