const db = require('./db');
const fs = require('fs');

const sampleConfig = {
  questions: [
    {
      id: "q1",
      type: "categorize",
      label: "Categorize the following items",
      image: null,
      data: { items: ["Apple","Car","Banana","Truck"], categories: ["Fruit","Vehicle"] }
    },
    {
      id: "q2",
      type: "cloze",
      label: "Fill the blank: The capital of France is ____.",
      data: {}
    },
    {
      id: "q3",
      type: "comprehension",
      label: "Read the paragraph and answer: What is the main idea?",
      data: { passage: "This is a short passage about environment..." }
    }
  ]
};

db.run("INSERT INTO forms (title, description, header_image, config) VALUES (?,?,?,?)",
  ["Sample Form (sqlite)", "A sample seeded form.", null, JSON.stringify(sampleConfig)], function(err) {
    if (err) return console.error(err);
    console.log("Inserted form id:", this.lastID);
  });
