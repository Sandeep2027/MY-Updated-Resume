const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const dbPath = path.join(__dirname, 'data.sqlite3');
const db = new sqlite3.Database(dbPath);

// initialize tables if not exist
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS forms (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    description TEXT,
    header_image TEXT,
    config TEXT
  )`);
  db.run(`CREATE TABLE IF NOT EXISTS responses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    form_id INTEGER,
    answers TEXT,
    created_at TEXT
  )`);
});

// export run/get/all helpers for convenience
module.exports = {
  run: function(sql, params, cb) { db.run(sql, params, cb); },
  get: function(sql, params, cb) { db.get(sql, params, cb); },
  all: function(sql, params, cb) { db.all(sql, params, cb); },
  prepare: function(sql) { return db.prepare(sql); }
};
