import React, { useEffect, useState } from 'react';
import { View, FlatList, StyleSheet, ActivityIndicator, Text } from 'react-native';
import ProductCard from '../components/ProductCard';
import { fetchProducts } from '../services/api';

export default function Home({ navigation }) {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    const data = await fetchProducts();
    setProducts(data);
    setLoading(false);
  };

  if (loading) {
    return <ActivityIndicator style={{ flex: 1 }} size="large" color="#b04b4b" />;
  }

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Best Products</Text>
      <FlatList
        data={products}
        numColumns={2}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <ProductCard item={item} onPress={() => navigation.navigate('ProductDetails', { product: item })} />
        )}
        columnWrapperStyle={{ justifyContent: 'space-between' }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fdf1f1', padding: 10 },
  heading: { fontSize: 20, fontWeight: 'bold', color: '#b04b4b', marginBottom: 10 },
});
