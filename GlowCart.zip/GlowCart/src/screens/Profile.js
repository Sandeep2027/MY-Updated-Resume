import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';

export default function Profile({ navigation }) {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.name}>Jane Doe</Text>
      <Text style={styles.email}>jane.doe@email.com</Text>

      {['Address', 'Order History', 'Language', 'Notifications', 'Contact Us', 'Get Help', 'Privacy Policy', 'Terms & Conditions'].map((item, idx) => (
        <TouchableOpacity key={idx} style={styles.option}>
          <Text style={styles.optionText}>{item}</Text>
        </TouchableOpacity>
      ))}

      <TouchableOpacity style={[styles.option, { backgroundColor: '#f8d7da' }]} onPress={() => navigation.navigate('Login')}>
        <Text style={[styles.optionText, { color: '#b04b4b' }]}>Logout</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', padding: 20 },
  name: { fontSize: 22, fontWeight: 'bold', color: '#b04b4b' },
  email: { fontSize: 14, color: '#666', marginBottom: 20 },
  option: { padding: 15, backgroundColor: '#fce4ec', borderRadius: 10, marginBottom: 10 },
  optionText: { fontSize: 16, color: '#333' },
});
