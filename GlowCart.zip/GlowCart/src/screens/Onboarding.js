import React from 'react';
import { View, Text, ImageBackground, StyleSheet, TouchableOpacity } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';

export default function Onboarding({ navigation }) {
  return (
    <ImageBackground
      source={{ uri: 'https://images.unsplash.com/photo-1587913011848-b2d6a6f2826a?auto=format&fit=crop&w=900&q=80' }}
      style={styles.container}
    >
      <LinearGradient colors={['rgba(0,0,0,0.3)', 'rgba(0,0,0,0.7)']} style={styles.overlay}>
        <Text style={styles.logo}>Viorra</Text>
        <Text style={styles.tagline}>Your Beauty, Delivered</Text>
        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Login')}>
          <Text style={styles.buttonText}>Get Started</Text>
        </TouchableOpacity>
      </LinearGradient>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  overlay: { flex: 1, justifyContent: 'flex-end', alignItems: 'center', paddingBottom: 60 },
  logo: { fontSize: 48, color: '#fff', fontWeight: 'bold', fontFamily: 'serif' },
  tagline: { fontSize: 18, color: '#fce4ec', marginBottom: 30, fontStyle: 'italic' },
  button: { backgroundColor: '#b04b4b', paddingHorizontal: 40, paddingVertical: 12, borderRadius: 30, elevation: 5 },
  buttonText: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
});
