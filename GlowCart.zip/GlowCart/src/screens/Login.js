import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet, TouchableOpacity, ImageBackground, ScrollView } from 'react-native';
import CustomButton from '../components/CustomButton';

export default function Login({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  return (
    <ImageBackground
      source={{ uri: 'https://images.unsplash.com/photo-1601924572825-b47af5c98a26?auto=format&fit=crop&w=900&q=80' }}
      style={styles.bg}
    >
      <ScrollView contentContainerStyle={styles.overlay}>
        <Text style={styles.title}>Hello Again!</Text>
        <Text style={styles.subtitle}>Welcome back, you’ve been missed</Text>

        <TextInput
          placeholder="Enter your email"
          placeholderTextColor="#aaa"
          style={styles.input}
          value={email}
          onChangeText={setEmail}
        />
        <TextInput
          placeholder="Password"
          placeholderTextColor="#aaa"
          secureTextEntry
          style={styles.input}
          value={password}
          onChangeText={setPassword}
        />

        <TouchableOpacity onPress={() => {}}>
          <Text style={styles.forgot}>Forgot password?</Text>
        </TouchableOpacity>

        <CustomButton title="Log In" onPress={() => navigation.navigate('Home')} />

        <View style={styles.registerRow}>
          <Text style={styles.registerText}>Not a member? </Text>
          <TouchableOpacity onPress={() => navigation.navigate('Register')}>
            <Text style={styles.registerLink}>Register Now</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  bg: { flex: 1 },
  overlay: { padding: 20, flexGrow: 1, justifyContent: 'center', backgroundColor: 'rgba(0,0,0,0.5)' },
  title: { fontSize: 32, fontWeight: 'bold', color: '#fff', marginBottom: 10 },
  subtitle: { fontSize: 16, color: '#fce4ec', marginBottom: 30 },
  input: {
    backgroundColor: '#fff',
    padding: 14,
    borderRadius: 30,
    marginBottom: 15,
    fontSize: 16,
    color: '#333',
  },
  forgot: { color: '#fce4ec', marginBottom: 20 },
  registerRow: { flexDirection: 'row', justifyContent: 'center', marginTop: 20 },
  registerText: { color: '#fce4ec' },
  registerLink: { color: '#fff', fontWeight: 'bold' },
});
