import React from 'react';
import { View, Text, Image, StyleSheet, ScrollView } from 'react-native';
import CustomButton from '../components/CustomButton';

export default function ProductDetails({ route }) {
  const { product } = route.params;

  return (
    <ScrollView style={styles.container}>
      <Image source={{ uri: product.images[0] }} style={styles.image} />
      <View style={styles.content}>
        <Text style={styles.title}>{product.title}</Text>
        <Text style={styles.desc}>{product.description}</Text>
        <Text style={styles.price}>${product.price}</Text>

        <Text style={styles.sectionTitle}>Highlights</Text>
        <Text>- Width: {product.dimensions.width}</Text>
        <Text>- Height: {product.dimensions.height}</Text>
        <Text>- Warranty: {product.warrantyInformation}</Text>
        <Text>- Shipping: {product.shippingInformation}</Text>

        <Text style={styles.sectionTitle}>Ratings & Reviews</Text>
        {product.reviews.map((review, idx) => (
          <View key={idx} style={styles.review}>
            <Text style={styles.reviewer}>{review.reviewerName}</Text>
            <Text>{review.comment}</Text>
          </View>
        ))}

        <CustomButton title="Add to Bag" style={{ marginTop: 20 }} />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  image: { width: '100%', height: 300 },
  content: { padding: 15 },
  title: { fontSize: 22, fontWeight: 'bold', color: '#b04b4b', marginBottom: 10 },
  desc: { fontSize: 14, color: '#555', marginBottom: 10 },
  price: { fontSize: 18, fontWeight: 'bold', color: '#b04b4b', marginBottom: 15 },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', marginTop: 15, marginBottom: 5, color: '#b04b4b' },
  review: { marginBottom: 10 },
  reviewer: { fontWeight: 'bold', color: '#333' },
});
