import axios from 'axios';
import RNFS from 'react-native-fs';

const API_URL = 'https://dummyjson.com/products';

export const fetchProducts = async () => {
  try {
    const response = await axios.get(API_URL);
    const products = response.data.products.filter(p => p.category === 'beauty');

    // Save locally
    const filePath = `${RNFS.DocumentDirectoryPath}/products.json`;
    await RNFS.writeFile(filePath, JSON.stringify(products), 'utf8');

    return products;
  } catch (error) {
    console.error('Error fetching products:', error);
    return readLocalProducts();
  }
};

export const readLocalProducts = async () => {
  try {
    const filePath = `${RNFS.DocumentDirectoryPath}/products.json`;
    const exists = await RNFS.exists(filePath);
    if (exists) {
      const content = await RNFS.readFile(filePath, 'utf8');
      return JSON.parse(content);
    }
    return [];
  } catch (err) {
    console.error('Error reading local products:', err);
    return [];
  }
};
