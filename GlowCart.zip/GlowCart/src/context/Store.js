import React, { createContext, useState } from 'react';

export const StoreContext = createContext();

export default function StoreProvider({ children }) {
  const [cart, setCart] = useState([]);
  const [user, setUser] = useState(null);

  const addToCart = (product) => {
    setCart((prev) => [...prev, product]);
  };

  const removeFromCart = (id) => {
    setCart((prev) => prev.filter(item => item.id !== id));
  };

  return (
    <StoreContext.Provider value={{ cart, addToCart, removeFromCart, user, setUser }}>
      {children}
    </StoreContext.Provider>
  );
}
