import React from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';

export default function ProductCard({ item, onPress }) {
  return (
    <TouchableOpacity style={styles.card} onPress={onPress}>
      <Image source={{ uri: item.thumbnail }} style={styles.image} />
      <View style={{ padding: 8 }}>
        <Text style={styles.title} numberOfLines={1}>{item.title}</Text>
        <Text style={styles.price}>${item.price}</Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: { width: '48%', backgroundColor: '#fff', borderRadius: 15, overflow: 'hidden', marginBottom: 15, elevation: 5 },
  image: { width: '100%', height: 140 },
  title: { fontSize: 14, fontWeight: '600', color: '#333' },
  price: { fontSize: 14, fontWeight: 'bold', color: '#b04b4b', marginTop: 4 },
});
